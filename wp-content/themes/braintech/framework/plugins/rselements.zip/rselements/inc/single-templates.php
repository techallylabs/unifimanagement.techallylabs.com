<?php
/*function rsaddon_elements_team_get_custom_post_type_template($single_template) {
    global $post;
    if ($post->post_type == 'teams') {
        $single_template = dirname( __FILE__ ) . '/single-teams.php';
    }
    return $single_template;
}
add_filter( 'single_template', 'rsaddon_elements_team_get_custom_post_type_template' );

/*function rsaddon_elements_portfolio_get_custom_post_type_template($single_template) {
    global $post;
    if ($post->post_type == 'portfolios') {
        $single_template = dirname( __FILE__ ) . '/single-portfolios.php';
    }
    return $single_template;
}
add_filter( 'single_template', 'rsaddon_elements_portfolio_get_custom_post_type_template' );*/